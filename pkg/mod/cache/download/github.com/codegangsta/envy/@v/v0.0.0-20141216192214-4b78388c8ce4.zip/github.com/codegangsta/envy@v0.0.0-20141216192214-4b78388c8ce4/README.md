envy
====

General purpose environment bootstrapper
